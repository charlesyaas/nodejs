
async function writeToLog (req, payload) {
	//not implemented
}
export default writeToLog;
